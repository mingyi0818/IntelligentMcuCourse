#include <stc89c52rc.h>

/* 粗略毫秒延时（11.0592MHz，12T） */
void delay_ms(unsigned int ms) {
    unsigned int i;
    while (ms--)
        for (i = 0; i < 92; i++)
            __asm__("nop");
}

void main(void) {
    unsigned char led = 0x01;          /* 点亮位：0000_0001 */
    while (1) {
        P1 = led;                      /* 输出到 LED（高电平点亮） */
        delay_ms(200);
        led <<= 1;                     /* 左移一位 */
        if (led == 0) led = 0x01;      /* 移出后回到最低位 */
    }
}