#include <stc89c52rc.h>

/* 共阳数码管段码表 0~9（段低电平点亮） */
const unsigned char code segTable[] = {
    0xC0, 0xF9, 0xA4, 0xB0, 0x99,
    0x92, 0x82, 0xF8, 0x80, 0x90
};
/* 位选（P2.0~P2.3 轮流输出低电平选中……共阳位选高有效时取反） */
const unsigned char code digBit[] = { 0x01, 0x02, 0x04, 0x08 };

void delay_ms(unsigned int ms) {
    unsigned int i;
    while (ms--)
        for (i = 0; i < 92; i++)
            __asm__("nop");
}

void display(unsigned int n) {
    unsigned char buf[4];
    unsigned char i;
    buf[0] = n / 1000;
    buf[1] = n / 100 % 10;
    buf[2] = n / 10 % 10;
    buf[3] = n % 10;
    for (i = 0; i < 4; i++) {
        P2 = digBit[i];             /* 选通第 i 位（共阳：高选中） */
        P0 = segTable[buf[i]];      /* 送段码（低电平点亮） */
        delay_ms(2);                /* 点亮 2ms */
        P0 = 0xFF;                  /* 消隐 */
    }
}

void main(void) {
    unsigned int n = 0;
    unsigned char tick = 0;
    while (1) {
        display(n);
        if (++tick >= 15) {         /* 约 0.5 秒加 1 */
            tick = 0;
            n++;
            if (n > 9999) n = 0;
        }
    }
}