#include <stc89c52rc.h>

void delay_ms(unsigned int ms) {
    unsigned int i;
    while (ms--)
        for (i = 0; i < 92; i++)
            __asm__("nop");
}

void main(void) {
    unsigned char led = 0x01;
    bit dir = 0;                    /* 0=左移 1=右移 */
    while (1) {
        if (P2_0 == 0) {            /* K1 按下：流水运行 */
            P1 = led;
            delay_ms(150);
            if (dir == 0) {
                led <<= 1;
                if (led == 0) led = 0x01;
            } else {
                led >>= 1;
                if (led == 0) led = 0x80;
            }
        } else if (P2_1 == 0) {     /* K2 按住：反向 */
            dir = 1;
            P1 = 0x00;
        } else {
            dir = 0;
            P1 = 0x00;              /* 松开熄灭 */
        }
    }
}