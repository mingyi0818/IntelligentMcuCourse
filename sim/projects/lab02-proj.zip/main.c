#include <stc89c52rc.h>

/* 延时约 ms 毫秒（11.0592MHz、12T 实测标定：内层 250+52 次 ≈ 1ms）。
   注意不要写成 for (i = 0; i < 307; i++)：常数超过 255 会退化成 16 位比较，
   每次循环变慢 2~3 倍，延时就不准了。 */
void delay_ms(unsigned int ms) {
    unsigned char i;
    while (ms--) {
        for (i = 0; i < 250; i++) __asm__("nop");
        for (i = 0; i < 52; i++)  __asm__("nop");
    }
}

void main(void) {
    unsigned char led = 0x01;
    unsigned char dir = 0;          /* 0 = D1→D8（左移），1 = D8→D1（右移） */
    unsigned char k2_lock = 0;      /* K2 已触发，等松开后才允许下一次切换 */

    while (1) {
        /* ---- K2：方向键，按一下切换一次（10ms 消抖 + 松开锁定） ---- */
        if (P2_1 == 0) {
            delay_ms(10);
            if (P2_1 == 0 && k2_lock == 0) {
                dir ^= 1;
                k2_lock = 1;
            }
        } else {
            k2_lock = 0;
        }

        /* ---- K1：运行键，按住流水、松开熄灭 ---- */
        if (P2_0 == 0) {
            P1 = led;               /* 点亮当前这只 LED（P1.0~P1.7 对应 D1~D8） */
            delay_ms(500);          /* 每 500ms 换下一个灯 */
            if (dir == 0) {
                led <<= 1;
                if (led == 0) led = 0x01;
            } else {
                led >>= 1;
                if (led == 0) led = 0x80;
            }
        } else {
            P1 = 0x00;              /* 松开 K1：全灭，下次接着当前灯位继续 */
        }
    }
}
