#include <stc89c52rc.h>

/* ================= 引脚定义（与电路模板一致；用头文件位定义别名） ================= */
#define ADC_CS  P2_0    /* ADC0832 片选 */
#define ADC_CLK P2_1    /* ADC0832 时钟 */
#define ADC_DI  P2_2    /* ADC0832 数据输入（通道选择） */
#define ADC_DO  P2_3    /* ADC0832 数据输出 */
#define KEY_UP  P2_4    /* 开阀阈值 +5% */
#define KEY_DN  P2_5    /* 开阀阈值 -5% */
#define KEY_HI  P2_6    /* 关阀阈值 +5% */
#define LCD_E   P2_7
#define LCD_RS  P3_6
#define LCD_RW  P3_7
#define PUMP    P3_5    /* 电磁阀 / 水泵 */

unsigned char th_low  = 45;   /* 开阀下限（含水量 %） */
unsigned char th_high = 60;   /* 关阀上限（含水量 %） */
unsigned char valve = 0;      /* 阀门状态：0 关 / 1 开 */

/* ================= 延时：Timer0 16 位，1ms @11.0592MHz ================= */
void delay_ms(unsigned int ms) {
    while (ms--) {
        TH0 = (65536 - 922) >> 8;
        TL0 = (65536 - 922) & 0xFF;
        TR0 = 1;
        while (!TF0);
        TR0 = 0;
        TF0 = 0;
    }
}

/* ================= ADC0832 串行读取（CH0，前导 0 + 8 位 MSB 优先） =================
 * 协议与数据手册一致：CS 拉低 → 首时钟上升沿且 DI=1 启动转换（输出前导 0），
 * 之后每个时钟上升沿输出一位（MSB 优先），CS 拉高结束。
 */
unsigned char adc_read(void) {
    unsigned char i, dat = 0;
    ADC_CS = 0;
    ADC_CLK = 0;
    ADC_DI = 1;
    NOP(); NOP();
    ADC_CLK = 1;            /* 上升沿：启动转换（前导 0，不读） */
    NOP(); NOP();
    ADC_CLK = 0;
    ADC_DI = 1;             /* 单通道（CH0） */
    for (i = 0; i < 8; i++) {
        ADC_CLK = 0;
        NOP(); NOP();
        dat <<= 1;
        ADC_CLK = 1;        /* 上升沿：输出一位 */
        NOP();
        if (ADC_DO) dat |= 1;
    }
    ADC_CS = 1;
    return dat;             /* 0~255，对应 0~5V（wp→0V，fc→5V） */
}

/* ================= LCD1602（8 位总线，P0 数据需外接上拉） ================= */
void lcd_write(unsigned char d, bit rs) {
    LCD_RS = rs;
    LCD_RW = 0;
    P0 = d;
    LCD_E = 1;
    NOP(); NOP();
    LCD_E = 0;
    delay_ms(1);
}
#define LCD_CMD(c) lcd_write(c, 0)
#define LCD_DAT(d) lcd_write(d, 1)

void lcd_pos(unsigned char pos) { LCD_CMD(0x80 | pos); }

void lcd_init(void) {
    delay_ms(20);
    LCD_CMD(0x38);          /* 8 位、2 行、5×7 点阵 */
    LCD_CMD(0x0C);          /* 开显示、关光标 */
    LCD_CMD(0x06);          /* 写入后指针自增 */
    LCD_CMD(0x01);          /* 清屏 */
    delay_ms(5);
}

void put2(unsigned char v) { LCD_DAT('0' + v / 10); LCD_DAT('0' + v % 10); }

void lcd_show(unsigned char m, unsigned char v) {
    lcd_pos(0x00);
    { const char* s = "SMART IRRIGATION "; while (*s) LCD_DAT(*s++); }
    lcd_pos(0x40);
    { const char* s = "M="; while (*s) LCD_DAT(*s++); }
    put2(m); LCD_DAT('%'); LCD_DAT(' ');
    { const char* s = "V:"; while (*s) LCD_DAT(*s++); }
    if (v) { const char* s = "ON "; while (*s) LCD_DAT(*s++); }
    else   { const char* s = "OFF"; while (*s) LCD_DAT(*s++); }
}

/* ================= 串口上报（9600bps） ================= */
void uart_init(void) {
    SCON = 0x50;            /* 方式1，允许接收 */
    TMOD |= 0x21;           /* T1 方式2（串口波特率）+ T0 方式1（延时） */
    TH1 = 0xFD;             /* 9600bps @11.0592MHz */
    TL1 = 0xFD;
    TR1 = 1;
}
void tx(unsigned char b) { SBUF = b; while (!TI); TI = 0; }
void puts1(const char* s) { while (*s) tx(*s++); }
void putdec(unsigned char v) {
    if (v >= 100) tx('0' + v / 100);
    tx('0' + (v / 10) % 10);
    tx('0' + v % 10);
}
void report(unsigned char m) {
    puts1("M=");  putdec(m);  tx('%');
    puts1(" LOW="); putdec(th_low);
    puts1(" HIGH="); putdec(th_high);
    puts1(" VALVE="); puts1(valve ? "ON" : "OFF");
    puts1("\r\n");
}

/* ================= 主程序：滞环控制 + 阈值设定 + 显示上报 ================= */
void main(void) {
    unsigned char adc, moist, rep = 10;
    lcd_init();
    uart_init();
    puts1("SMART-IRRIGATION v1.0 (orchard scene)\r\n");
    while (1) {
        /* 1) 读取土壤含水量 */
        adc = adc_read();
        moist = (unsigned char)((unsigned int)adc * 100 / 255);

        /* 2) 滞环控制：低于下限开阀，高于上限关阀（避免临界频繁启停） */
        if (!valve && moist < th_low) valve = 1;
        else if (valve && moist > th_high) valve = 0;
        PUMP = valve;

        /* 3) 按键设定阈值（软件消抖） */
        if (!KEY_UP) {
            delay_ms(15);
            if (!KEY_UP) { th_low = th_low <= 85 ? th_low + 5 : 90; while (!KEY_UP); }
        }
        if (!KEY_DN) {
            delay_ms(15);
            if (!KEY_DN) { th_low = th_low >= 15 ? th_low - 5 : 10; while (!KEY_DN); }
        }
        if (!KEY_HI) {
            delay_ms(15);
            if (!KEY_HI) { th_high = th_high <= 90 ? th_high + 5 : 95; while (!KEY_HI); }
        }

        /* 4) 显示与周期上报（约每 20 轮） */
        lcd_show(moist, valve);
        if (--rep == 0) { rep = 10; report(moist); }
    }
}
