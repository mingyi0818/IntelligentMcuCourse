#include <stc89c52rc.h>

/* ============ 串口调试打印三件套（本仿真内核实测可用） ============
   STC 单片机没有在线调试器——把内部变量经串口打印到 PC 是最常用调试手段。
   标准库 printf 在 Keil/实物上可用；实验采用与 printf 同原理的逐字符打印函数：直接写 SBUF 发往串口，便于观察每一步输出。 */
void uart_putc(char c) { SBUF = c; while (!TI); TI = 0; }
void uart_puts(const char *s) { while (*s) uart_putc(*s++); }
void uart_putnum(unsigned int v) {          /* 十进制输出（数字转 ASCII） */
    char b[6]; char i = 0;
    if (v == 0) { uart_putc('0'); return; }
    while (v) { b[i++] = '0' + v % 10; v /= 10; }
    while (i) uart_putc(b[--i]);
}
void uart_init(void) {
    SCON = 0x50;                    /* 串口方式1，允许接收 */
    TMOD &= 0x0F; TMOD |= 0x20;     /* T1 方式2 作波特率发生器 */
    TH1 = 0xFD; TL1 = 0xFD;         /* 9600bps @11.0592MHz */
    TR1 = 1;
}

void main(void) {
    unsigned int cnt = 0;
    unsigned char state = 0;
    unsigned int d;
    uart_init();
    uart_puts("=== uart debug demo ===\r\n");
    while (1) {
        cnt++;
        state = cnt % 2;            /* 模拟一个内部状态 */
        uart_puts("count="); uart_putnum(cnt);
        uart_puts(" state="); uart_putnum(state); uart_puts("\r\n");
        /* 实际工程中在这里打印关键变量/分支走向，PC 端一目了然 */
        for (d = 0; d < 40000; d++) __asm__("nop");   /* 粗略延时 */
    }
}
