#include <stc89c52rc.h>

unsigned char led = 0x01;
unsigned int tick = 0;

void main(void) {
    TMOD = 0x01;                /* T0 方式1，16 位定时 */
    TH0 = 0x4C;                 /* 50ms 初值 @11.0592MHz */
    TL0 = 0x00;
    ET0 = 1;                    /* 允许 T0 中断 */
    EA = 1;                     /* 开总中断 */
    TR0 = 1;                    /* 启动 T0 */
    while (1)
        ;                       /* 主循环空转，全靠中断 */
}

void t0_isr(void) __interrupt(1) {
    TH0 = 0x4C;                 /* 重装初值 */
    TL0 = 0x00;
    if (++tick >= 10) {         /* 10 × 50ms = 0.5s */
        tick = 0;
        P1 = led;
        led <<= 1;
        if (led == 0) led = 0x01;
    }
}