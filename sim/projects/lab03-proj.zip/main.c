#include <stc89c52rc.h>

void delay_ms(unsigned int ms) {
    unsigned int i;
    while (ms--)
        for (i = 0; i < 92; i++)
            __asm__("nop");
}

/* 行扫描法：返回键号 1~16，无键返回 0 */
unsigned char key_scan(void) {
    unsigned char r, col;
    unsigned char tmp;
    for (r = 0; r < 4; r++) {
        P1 = ~(0x01 << r);              /* 当前行输出 0，其余为 1 */
        tmp = P1 & 0xF0;                /* 读高 4 位（列） */
        if (tmp != 0xF0) {
            delay_ms(10);               /* 消抖 */
            tmp = P1 & 0xF0;
            if (tmp != 0xF0) {
                switch (tmp) {
                    case 0xE0: col = 0; break;
                    case 0xD0: col = 1; break;
                    case 0xB0: col = 2; break;
                    default:   col = 3; break;
                }
                while ((P1 & 0xF0) != 0xF0)
                    ;                   /* 等待按键释放 */
                return r * 4 + col + 1; /* 键号 1~16 */
            }
        }
    }
    return 0;
}

void main(void) {
    unsigned char key;
    P2 = 0x00;
    while (1) {
        key = key_scan();
        if (key)
            P2 = key;                   /* 键号以二进制显示在 LED 上 */
    }
}