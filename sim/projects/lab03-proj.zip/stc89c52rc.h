#ifndef __STC89C52RC_H__
#define __STC89C52RC_H__
/*===========================================================================
 * STC89C52RC 寄存器定义头文件（单片机虚拟仿真实验系统定制版）
 * 资源：8K Flash / 512B RAM(256直接+256间接) / 4K EEPROM
 *      3个16位定时器(T0,T1,T2) / 1个全双工UART / 6个中断源 / 4级中断优先级
 *      12T(默认)或6T机器周期，晶振默认 11.0592MHz
 * 用法：#include <stc89c52rc.h>  然后直接写 main()，无需再写函数原型
 *=========================================================================*/

#include <compiler.h>

/*===========================================================================
 * Keil C51 兼容宏
 * Keil 教材/课程代码常用无下划线关键字 code/data/idata/xdata/pdata/bit/sfr，
 * SDCC 4.x 要求写成 __code 等双下划线形式。此处统一映射，使 Keil 风格代码
 * （如 `unsigned char code tab[] = {...}`、`bit flag;`）无需修改即可编译。
 * 注意：① 代码里不要再定义名为 data/bit 的变量；② Keil 的
 *       `sbit X = P2^0;` 语法仍不支持，请使用下方 P2_0 等现成位定义。
 *=========================================================================*/
#define code   __code
#define data   __data
#define idata  __idata
#define xdata  __xdata
#define pdata  __pdata
#define bit    __bit
#define sfr    __sfr
#define sfr16  __sfr16
#define using  __using
#define _at_   __at
#define reentrant __reentrant

/*---------------------------- 端口 P0~P3 ----------------------------*/
__sfr __at(0x80) P0;   /* P0口：漏极开路，作I/O需外部上拉电阻 */
__sfr __at(0x90) P1;   /* P1口：准双向口，内部弱上拉 */
__sfr __at(0xA0) P2;   /* P2口：准双向口 */
__sfr __at(0xB0) P3;   /* P3口：准双向口，第二功能见下方 sbit */

/*---------------------------- 内核寄存器 ----------------------------*/
__sfr __at(0x81) SP;    /* 堆栈指针 */
__sfr __at(0x82) DPL;   /* 数据指针低8位 */
__sfr __at(0x83) DPH;   /* 数据指针高8位 */
__sfr __at(0x87) PCON;  /* 电源控制寄存器（SMOD=波特率倍增位） */
__sfr __at(0xD0) PSW;   /* 程序状态字 */
__sfr __at(0xE0) ACC;   /* 累加器A */
__sfr __at(0xF0) B;     /* B寄存器（乘除法辅助） */

/*---------------------------- 中断系统 ----------------------------*/
__sfr __at(0xA8) IE;    /* 中断允许寄存器 */
__sfr __at(0xB8) IP;    /* 中断优先级控制（低字节） */
__sfr __at(0xB7) IPH;   /* 中断优先级控制（高字节，STC，实现4级优先级） */

/*---------------------------- 定时器/计数器 ----------------------------*/
__sfr __at(0x88) TCON;  /* 定时器控制寄存器 */
__sfr __at(0x89) TMOD;  /* 定时器方式寄存器 */
__sfr __at(0x8A) TL0;   /* 定时器0低字节 */
__sfr __at(0x8B) TL1;   /* 定时器1低字节 */
__sfr __at(0x8C) TH0;   /* 定时器0高字节 */
__sfr __at(0x8D) TH1;   /* 定时器1高字节 */
__sfr __at(0xC8) T2CON; /* 定时器2控制寄存器（8052） */
__sfr __at(0xC9) T2MOD; /* 定时器2方式寄存器（STC，T2OE位可开P1.0时钟输出） */
__sfr __at(0xCA) RCAP2L;/* 定时器2重装载/捕获低字节 */
__sfr __at(0xCB) RCAP2H;/* 定时器2重装载/捕获高字节 */
__sfr __at(0xCC) TL2;   /* 定时器2低字节 */
__sfr __at(0xCD) TH2;   /* 定时器2高字节 */

/*---------------------------- 串行口 ----------------------------*/
__sfr __at(0x98) SCON;  /* 串行口控制寄存器 */
__sfr __at(0x99) SBUF;  /* 串行口数据缓冲器 */

/*---------------------------- STC 增强寄存器 ----------------------------*/
__sfr __at(0x8E) AUXR;  /* 辅助寄存器：T0x12/T1x12/UART_M0x6/T2x12 倍速位 */
__sfr __at(0xA2) AUXR1; /* 辅助寄存器1：bit0=DPS 双数据指针选择（不可位寻址） */
__sfr __at(0xE1) WDT_CONTR; /* 看门狗寄存器（教学实验默认关闭） */
__sfr __at(0xE8) P4;    /* P4口（仅LQFP-44/PLCC-44封装有引出） */

/* STC89C52RC IAP/IAP 操作寄存器（实验12 EEPROM 读写用） */
__sfr __at(0xE2) ISP_DATA;  /* EEPROM数据寄存器 */
__sfr __at(0xE3) ISP_ADDRH; /* EEPROM地址高字节 */
__sfr __at(0xE4) ISP_ADDRL; /* EEPROM地址低字节 */
__sfr __at(0xE5) ISP_CMD;   /* ISP命令寄存器：1=读 2=写 3=扇区擦除 */
__sfr __at(0xE6) ISP_TRIG;  /* ISP触发寄存器：先写0x5A再写0xA5生效 */
__sfr __at(0xE7) ISP_CONTR; /* ISP控制寄存器：0x80=允许ISP，0x10=复位后进ISP */

/* 双数据指针选择宏（AUXR1 不可位寻址，用字节操作） */
#define DPTR_SELECT_1() (AUXR1 |= 0x01)
#define DPTR_SELECT_0() (AUXR1 &= ~0x01)

/*=========================== 位寻址定义 ===========================*/

/* P0 口位定义 */
__sbit __at(0x80) P0_0; __sbit __at(0x81) P0_1; __sbit __at(0x82) P0_2; __sbit __at(0x83) P0_3;
__sbit __at(0x84) P0_4; __sbit __at(0x85) P0_5; __sbit __at(0x86) P0_6; __sbit __at(0x87) P0_7;

/* P1 口位定义 */
__sbit __at(0x90) P1_0; __sbit __at(0x91) P1_1; __sbit __at(0x92) P1_2; __sbit __at(0x93) P1_3;
__sbit __at(0x94) P1_4; __sbit __at(0x95) P1_5; __sbit __at(0x96) P1_6; __sbit __at(0x97) P1_7;

/* P2 口位定义 */
__sbit __at(0xA0) P2_0; __sbit __at(0xA1) P2_1; __sbit __at(0xA2) P2_2; __sbit __at(0xA3) P2_3;
__sbit __at(0xA4) P2_4; __sbit __at(0xA5) P2_5; __sbit __at(0xA6) P2_6; __sbit __at(0xA7) P2_7;

/* P3 口位定义（含第二功能名） */
__sbit __at(0xB0) P3_0; __sbit __at(0xB1) P3_1; __sbit __at(0xB2) P3_2; __sbit __at(0xB3) P3_3;
__sbit __at(0xB4) P3_4; __sbit __at(0xB5) P3_5; __sbit __at(0xB6) P3_6; __sbit __at(0xB7) P3_7;
__sbit __at(0xB0) RXD;   /* 串行输入 */
__sbit __at(0xB1) TXD;   /* 串行输出 */
__sbit __at(0xB2) INT0;  /* 外部中断0 */
__sbit __at(0xB3) INT1;  /* 外部中断1 */
__sbit __at(0xB4) T0;    /* 定时器0外部计数输入 */
__sbit __at(0xB5) T1;    /* 定时器1外部计数输入 */
__sbit __at(0xB6) WR;    /* 外部RAM写选通 */
__sbit __at(0xB7) RD;    /* 外部RAM读选通 */

/* TCON 位定义 */
__sbit __at(0x88) IT0;   /* 外部中断0触发方式：0=低电平 1=下降沿 */
__sbit __at(0x89) IE0;   /* 外部中断0中断标志 */
__sbit __at(0x8A) IT1;   /* 外部中断1触发方式 */
__sbit __at(0x8B) IE1;   /* 外部中断1中断标志 */
__sbit __at(0x8C) TR0;   /* 定时器0运行控制 */
__sbit __at(0x8D) TF0;   /* 定时器0溢出标志 */
__sbit __at(0x8E) TR1;   /* 定时器1运行控制 */
__sbit __at(0x8F) TF1;   /* 定时器1溢出标志 */

/* SCON 位定义 */
__sbit __at(0x98) RI;    /* 接收中断标志 */
__sbit __at(0x99) TI;    /* 发送中断标志 */
__sbit __at(0x9A) RB8;   /* 接收的第9位 */
__sbit __at(0x9B) TB8;   /* 发送的第9位 */
__sbit __at(0x9C) REN;   /* 允许接收 */
__sbit __at(0x9D) SM2;   /* 多机通信控制 */
__sbit __at(0x9E) SM1;   /* 方式位1 */
__sbit __at(0x9F) SM0;   /* 方式位0 */

/* IE 位定义 */
__sbit __at(0xA8) EX0;   /* 外部中断0允许 */
__sbit __at(0xA9) ET0;   /* 定时器0中断允许 */
__sbit __at(0xAA) EX1;   /* 外部中断1允许 */
__sbit __at(0xAB) ET1;   /* 定时器1中断允许 */
__sbit __at(0xAC) ES;    /* 串行口中断允许 */
__sbit __at(0xAD) ET2;   /* 定时器2中断允许 */
__sbit __at(0xAF) EA;    /* 总中断允许 */

/* IP 位定义 */
__sbit __at(0xB8) PX0;   /* 外部中断0优先级 */
__sbit __at(0xB9) PT0;   /* 定时器0优先级 */
__sbit __at(0xBA) PX1;   /* 外部中断1优先级 */
__sbit __at(0xBB) PT1;   /* 定时器1优先级 */
__sbit __at(0xBC) PS;    /* 串行口优先级 */
__sbit __at(0xBD) PT2;   /* 定时器2优先级 */

/* PSW 位定义 */
__sbit __at(0xD0) P;     /* 奇偶校验位 */
__sbit __at(0xD1) F1;    /* 用户标志1 */
__sbit __at(0xD2) OV;    /* 溢出标志 */
__sbit __at(0xD3) RS0;   /* 工作寄存器组选择0 */
__sbit __at(0xD4) RS1;   /* 工作寄存器组选择1 */
__sbit __at(0xD5) F0;    /* 用户标志0 */
__sbit __at(0xD6) AC;    /* 辅助进位标志 */
__sbit __at(0xD7) CY;    /* 进位标志 */

/* T2CON 位定义 */
__sbit __at(0xC8) CP_RL2; /* 0=定时器 1=计数器 */
__sbit __at(0xC9) C_T2;   /* 捕获/重装选择 */
__sbit __at(0xCA) TR2;    /* 定时器2运行控制 */
__sbit __at(0xCB) EXEN2;  /* 定时器2外部捕获允许 */
__sbit __at(0xCC) TCLK;   /* 串口发送波特率使用定时器2 */
__sbit __at(0xCD) RCLK;   /* 串口接收波特率使用定时器2 */
__sbit __at(0xCE) EXF2;   /* 定时器2外部捕获标志 */
__sbit __at(0xCF) TF2;    /* 定时器2溢出标志 */

/* 看门狗 WDT_CONTR 位定义 */
#define WDT_FLAG 0x80
#define EN_WDT  0x20
#define CLR_WDT 0x10
#define IDLE_WDT 0x08

#endif /* __STC89C52RC_H__ */
