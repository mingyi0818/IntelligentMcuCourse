@echo off
setlocal
where sdcc >nul 2>nul
if errorlevel 1 (
  echo [ERROR] SDCC was not found in PATH.
  echo Install SDCC from https://sdcc.sourceforge.net/ and reopen this window.
  if not "%MVL_NO_PAUSE%"=="1" pause
  exit /b 1
)
sdcc -mmcs51 --std-sdcc11 --model-small --debug --data-loc 0x30 --stack-loc 0x80 -I. -o main main.c
if errorlevel 1 goto fail
if not exist main goto fail
if exist project.hex del /q project.hex
ren main project.hex
echo [OK] Generated project.hex - import it into the online simulator.
if not "%MVL_NO_PAUSE%"=="1" pause
exit /b 0
:fail
echo [ERROR] Build failed. Read the compiler messages above.
if not "%MVL_NO_PAUSE%"=="1" pause
exit /b 1
