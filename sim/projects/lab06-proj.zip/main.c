#include <stc89c52rc.h>

void uart_init(void) {
    SCON = 0x50;                /* 方式1，允许接收 */
    TMOD |= 0x20;               /* T1 方式2，8位自动重装 */
    TH1 = 0xFD;                 /* 9600bps @11.0592MHz */
    TL1 = 0xFD;
    TR1 = 1;                    /* 启动 T1 */
}

void uart_send(unsigned char c) {
    SBUF = c;                   /* 启动发送 */
    while (!TI)
        ;                       /* 等待发送完成 */
    TI = 0;                     /* 软件清发送标志 */
}

void main(void) {
    unsigned char c;
    uart_init();
    uart_send('O');
    uart_send('K');
    uart_send('\r');
    uart_send('\n');
    while (1) {
        if (RI) {               /* 收到一个字节 */
            RI = 0;
            c = SBUF;           /* 取出数据 */
            P1 = c;             /* LED 显示字节值 */
            uart_send(c);       /* 原样回显 */
        }
    }
}