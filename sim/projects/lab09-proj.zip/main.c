#include <stc89c52rc.h>

/* 定时器0 方式1：50ms 中断一次（11.0592MHz，机器周期 1.085us，50ms = 46080 周期，初值 65536-46080 = 0x4C00） */
void Timer0_Init(void) {
    TMOD &= 0xF0; TMOD |= 0x01;    /* 定时器0 方式1（16 位） */
    TH0 = 0x4C; TL0 = 0x00;        /* 50ms 初值 */
    ET0 = 1; EA = 1; TR0 = 1;      /* 开中断、启动 */
}

void main(void) {
    Timer0_Init();
    while (1);                      /* 全部工作在中断里完成 */
}

void Timer0_ISR(void) __interrupt(1) {
    static unsigned char n1 = 0, n2 = 0;
    TH0 = 0x4C; TL0 = 0x00;        /* 重装初值 */
    if (++n1 >= 2) { n1 = 0; P2_6 = !P2_6; }   /* CH1: 每 100ms 翻转 → 精确 5Hz 方波 */
    if (++n2 >= 5) { n2 = 0; P2_7 = !P2_7; }   /* CH2: 每 250ms 翻转 → 精确 2Hz 方波 */
}
