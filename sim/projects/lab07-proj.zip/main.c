#include <stc89c52rc.h>

/* 使用 stc89c52rc.h 中定义的位名（SDCC 语法，等价 Keil 的 sbit） */
#define LCD_RS P2_0
#define LCD_RW P2_1
#define LCD_E  P2_2

#define LCD_DAT P0

void delay_ms(unsigned int ms) {
    unsigned int i;
    while (ms--)
        for (i = 0; i < 92; i++)
            __asm__("nop");
}

void lcd_wait(void) {           /* 读忙（虚拟屏即时就绪，保留标准流程） */
    unsigned char s;
    LCD_DAT = 0xFF;             /* 准双向口读之前先写 1 */
    LCD_RS = 0;
    LCD_RW = 1;
    do {
        LCD_E = 1;
        s = LCD_DAT;
        LCD_E = 0;
    } while (s & 0x80);
}

void lcd_cmd(unsigned char c) {
    lcd_wait();
    LCD_RS = 0; LCD_RW = 0;
    LCD_DAT = c;
    LCD_E = 1; delay_ms(1); LCD_E = 0;
    delay_ms(1);
}

void lcd_dat(unsigned char d) {
    lcd_wait();
    LCD_RS = 1; LCD_RW = 0;
    LCD_DAT = d;
    LCD_E = 1; delay_ms(1); LCD_E = 0;
    delay_ms(1);
}

void lcd_init(void) {
    delay_ms(20);               /* 上电等待 */
    lcd_cmd(0x38);              /* 8位接口，两行显示 */
    lcd_cmd(0x0C);              /* 开显示，关光标 */
    lcd_cmd(0x06);              /* 写后地址自动加一 */
    lcd_cmd(0x01);              /* 清屏 */
    delay_ms(2);
}

void lcd_str(unsigned char row, const char *s) {
    lcd_cmd(0x80 + (row == 0 ? 0x00 : 0x40));
    while (*s)
        lcd_dat(*s++);
}

void main(void) {
    unsigned char sec = 0;
    lcd_init();
    lcd_str(0, "Hello MCU!");
    while (1) {
        lcd_cmd(0xC0);        /* 第二行首 */
        lcd_dat('R');
        lcd_dat('u');
        lcd_dat('n');
        lcd_dat(':');
        lcd_dat(' ' + sec / 100);
        lcd_dat('0' + sec / 10 % 10);
        lcd_dat('0' + sec % 10);
        lcd_dat('s');
        delay_ms(1000);
        sec++;                /* unsigned char 255 后自动回 0 */
    }
}